# Install version 9.0.7

Use **NKPI_v907_GitHub_Upload.zip**. Extract the outer download once.

Upload the four extracted top-level files to the root of the existing GitHub repository: `kcn_dual_calculator_app.py`, `nkpi_runtime.zip`, `requirements.txt` and `README.md`. Preserve the fifth file's path as `.streamlit/config.toml`. Replace matching files. **Keep the inner `nkpi_runtime.zip` intact**; the launcher automatically unpacks it on the server. The application folders do not need a separate upload.

Keep **kcn_dual_calculator_app.py** as Streamlit's main file in the correct repository and branch. Python **3.12** remains the target runtime. Reboot the app and refresh the browser; confirm **9.0.7-anatomical-eye** in the footer. Reimport the original report ZIPs, verify the measurements and calculate.

In **Regional change & 3D corneal view → Current case → OD/OS → 3D corneal view**, the default **Surface shape** view uses solid shading. **Close-up** frames the source corneal area. **Shape profile** uses a supported anterior-elevation feature as an inspection location, not a clinically validated cone apex. **Natural eye**, map overlays, rotation and optional cutaway remain available.

**True scale** retains the source-derived geometry. Optional **3× / 6× relief** applies only to report-image estimates and is visibly labeled; measurements and NKPI results remain unchanged. The report-based cornea is approximate, its inner surface is inferred from thickness, and the surrounding eye is reference anatomy.

Older `nkpi`, `components`, `models` or `research` folders can remain because the launcher loads the bundled release first. No new API key is required. If the bundle is missing or does not match the launcher, upload the launcher and `nkpi_runtime.zip` together from the same download and reboot. Do not rename either file or put the release inside an additional enclosing folder.
