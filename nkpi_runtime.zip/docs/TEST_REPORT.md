# Version 9.0.7 software verification — 16 October 2026

This release changes corneal shape presentation and adds a source-inspection helper. The checks below establish software behavior and calculation continuity, not exact patient anatomy or clinical accuracy.

- **Preserved calculator:** all three stored model artifacts are byte-identical to 9.0.6. All 36 complete calculation results matched exactly after excluding only the interface version, across baseline/longitudinal modes, OD/OS, three ages and three measurement patterns. Configuration also matched. Python edits are only the service version and component/key identifiers; no model was refit.
- **Existing Python checks:** all 41 unit tests passed (15 evidence and 26 baseline/retained-backend), plus the separate interval-weight and independent impact-audit script. The historical research-training suite was not rerun because fitting code and coefficients are unchanged.
- **JavaScript regression:** all ten test files passed. These include all 70 existing regional/image/3D/cone groups and 24 focused helper/renderer groups. All 24 nonvendor JavaScript files parsed, and all 34 local HTML references resolved. The new helper loads before the viewer.
- **Geometry checks:** 1×/3×/6× transforms, unchanged source coordinates and thickness values, front/back paired shifts, native/reference no-amplification, cache reuse/invalidation, equal-axis projection, profile orientation across quadrants, source-only sampling, null-gap breaks, contour placement, unchanged BFS reference, and off-meridian marker exclusion passed. Reference anatomy does not acquire patient elevation or a fabricated cone.
- **Mounted controls:** twelve DOM-and-Canvas integration checks executed the actual browser-module code and event handlers. They covered the default solid close-up, profile button, relief selector, natural/map modes, visit switching, whole-eye/front/3D controls, cutaway, keyboard rotation, reconstruction mode, source immutability, cleanup and reference-only behavior. Saved figures included the active section and correct true-scale/relief filename at 1000- and 390-pixel widths. This was a DOM test environment, not a full browser engine.
- **Visual inspection:** the production renderer was inspected using explicitly synthetic off-axis elevation and thickness fields. True-scale and ×6 surface, natural-eye, whole-eye, side-profile, combined-map and cutaway views rendered; the source cross-section and mobile labels were inspected. The ×6 side silhouette and shaded surface showed the expected source-linked deformation. A small-screen relief-label size problem was corrected. No patient shape was inferred from the supplied UI screenshots.
- **Loader regression:** all eleven targeted bootstrap tests passed, including arbitrary working directories, stale package imports, updated release activation, cache reuse, concurrent installers, binary assets, unsafe/corrupt/missing ZIP rejection, and original-error propagation.
- **Packaged application:** clean extraction yielded exactly five upload files and 101 runtime files. All 100 manifest entries matched SHA-256 and extracted bytes. Streamlit AppTest started the launcher from a different directory with no app exceptions or error elements and one registered component. Actual entrypoint assess events produced OD/OS results and PDF byte streams in baseline and longitudinal modes.
- **Local asset serving:** a real local Streamlit WebSocket session ran without a script exception. Ten component assets returned HTTP 200 with exact source hashes, including the new shape helper, renderer, UI, importer and both English OCR data files.
- **Environment:** Python 3.12.14, Streamlit 1.50.0, ReportLab 4.4.9 and NumPy 2.5.4; the original compatible requirements are retained. Canvas QA used the production JavaScript with a local Canvas implementation. The Node-to-Python integration suite required execution outside the restricted test sandbox and passed there. DOM test dependencies are temporary QA tools and are not added to the application.
- **Verification limits:** no live GitHub or Streamlit Cloud deployment was changed or tested. Actual browser layout/interaction and a new end-to-end patient ZIP/OCR import were not run; the headless browser download was unavailable. New geometry fixtures were synthetic. Report-image geometry retains its BFS-position assumptions and thickness-derived inner surface. The profile feature is an inspection location, not a validated cone apex. Optional relief is visibly exaggerated and does not change source measurements or analysis.

Distribution contains the complete app, models, extraction/OCR assets, tests and documentation. It excludes private patient reports, extracted patient grids, temporary dependencies and QA images. The upload remains four root files plus `.streamlit/config.toml`; keep the inner `nkpi_runtime.zip` intact.

---

# Version 9.0.6 software verification — 16 October 2026

This is a delivery and startup repair of the recovered complete 9.0.5 application. It preserves all latest viewer additions and the stored model artifacts. These are software checks, not new clinical validation.

- **Isolated environment:** Python 3.12.14, Streamlit 1.50.0, ReportLab 4.4.9 and NumPy 2.5.4. The original `requirements.txt` is retained: Streamlit and ReportLab are pinned, while NumPy keeps its existing compatible range so older supported Python deployments can resolve an appropriate release. The tested Python 3.12 resolution used NumPy 2.5.4.
- **Loader checks:** all 11 targeted checks passed, including launch from another working directory, stale imported root `nkpi` modules, changing releases, binary-asset preservation, cached reuse, six concurrent installers, omitted/mismatched/malformed bundles, missing required source, unsafe ZIP entries, and propagation of original application errors.
- **Startup:** Streamlit AppTest executed the bundled entrypoint from outside its directory with zero app exceptions, zero error elements and one registered custom component. The original package import was reproduced as failing in that working-directory scenario; the explicit bundled import route succeeds.
- **Model and calculation continuity:** registry and both trained-model JSON files are byte-identical to 9.0.5. Scoring assessment, impact audit, evidence, retained forecast backend, scalar extraction, image analysis, regional analysis and 3D geometry code are also byte-identical. All outputs apart from the release label matched exactly for 36 representative eye calculations across both eyes, both calculator modes, three ages and three measurement patterns.
- **Server event handling:** simulated assess events passed through the actual Streamlit entrypoint for baseline and longitudinal OD/OS cases; all four produced scores and PDF byte streams. Omitted optional quality/history fields and quality warnings retained valid verified scores.
- **Existing Python checks:** all 15 evidence tests and 26 baseline/retained-backend tests passed (41 total), plus the separate interval-weight and independent impact-audit script. The historical research-training suite was not rerun; no model fitting code or fitted coefficients were changed.
- **Existing JavaScript checks:** all nine test files passed, including 70 regional/image/3D/cone groups. All 23 nonvendor JavaScript files parsed successfully and all 33 local HTML asset references resolved. The Node-to-Python integration test required running outside the restricted test sandbox; it passed there.
- **Actual local server:** a Streamlit WebSocket session executed the packaged application without a script exception. Nine calculator, regional-viewer, 3D-viewer, importer and OCR resources were retrieved successfully through Streamlit's component endpoint, with byte hashes matching their source files. Both English OCR model files were included.
- **Archive integrity:** standard unencrypted DEFLATE ZIPs; outer upload has five files, and inner runtime retains all 99 original source paths. The runtime manifest verifies all 98 nonmanifest files. Temporary caches, private patient reports and test outputs are excluded.
- **Limits of this turn's verification:** no live GitHub/Streamlit Cloud deployment was changed or tested. No new patient scan was available for extraction validation. The headless browser download was unavailable, so actual browser clicks, rendering, and CDN-based OCR were not retested. 3D logic regression checks and actual asset serving passed; earlier visual inspections below are historical. Report-derived shape remains approximate, and reference anatomy remains illustrative.

---

# Version 9.0.5 software verification — 16 October 2026

This release adds a continuous anatomical display around the existing source model. Software verification does not establish exact patient anatomy or clinical accuracy.

- All nine JavaScript suites passed. The regional/image/3D/cone suite now has 70 test groups, including supported-coordinate preservation, separate missing-data completion, circular rim closure, reference-eye junction, reconstructed-color isolation, reference-only behavior, off-center cone preservation and native posterior/laterality checks.
- All 41 Python tests passed. Frozen model artifacts, scoring assessment, scalar extraction and the image reader are unchanged from 9.0.4. Interface/cache identifiers were updated to 9.0.5.
- All eight retained private eye/visit reconstructions rendered with six overlays. Front, side, cutaway and optional elevation emphasis completed. Source geometry remained unchanged, and picking IDs still identify original supported samples rather than interpolated values. These checks passed again after the final rendering optimization.
- Production Canvas images were inspected in natural, front, side, close-up, cutaway, combined and reconstruction modes. A compact-width reference view was also inspected. Labels, the continuous shell and the optional cutaway wall were checked visually.
- Display completion holds supported source nodes fixed and preserves missing values, source coverage, regional calculations and tracker inputs. Interpolated display colors do not become numerical measurements or supported thickness contours. No patient cone is inferred from NKPI or Kmax alone.
- **Verification limit:** browser interaction/layout and live Streamlit deployment were not tested because the supported browser QA capability was unavailable. Canvas rendering and automated tests do not replace browser acceptance testing. Browser results in older sections are historical.
- Distribution retains 99 files, standard unencrypted ZIP DEFLATE, CRC testing and clean-extraction manifest verification. No patient reports, extracted patient grids or private QA renders are packaged.

---

# Version 9.0.4 software verification — 16 October 2026

This release changes presentation of the corneal geometry and descriptive cone tracker. It does not establish an exact anatomical replica or a clinically validated cone boundary.

- All nine JavaScript suites passed. The regional/image/3D/cone suite contains 62 groups. Added cases verify that reference gap patches have no measured cells or IDs; elevation emphasis leaves source values and front/back separation unchanged; iso-thickness contours recover an analytic linear field; combined mode requires both inputs; joined outlines preserve rectangular cell and hole areas; and unresolved image change / sub-grid movement receive explicit labels.
- All 41 Python tests passed. Frozen model artifacts, scoring assessment, scalar extraction and the image reader remain unchanged. Interface/cache identifiers were updated to 9.0.4.
- All eight existing private eye/visit reconstructions rendered with six views (combined, shape, thickness, anterior curvature, posterior curvature and elevation). Front, side, cutaway and optional emphasized rendering completed. Selected IDs still refer to supported source vertices; switching overlays preserves the source geometry.
- Production Canvas output was inspected, including the unsupported inferior patch, integrated contours and simplified tracker. The public preview is entirely fictional and contains no patient report or extracted patient data.
- Tracker segmentation, fixed threshold, matched-region logic and quantitative calculations are unchanged from 9.0.3. Changes smaller than a grid step or within printed color-bin resolution are not presented as resolved movements or changes.
- The display uses a separate striped reference patch where data are unavailable. This does not increase measured coverage. The optional ×3 view is visibly labeled and defaults off; reported values and the inset remain at true scale. The inset follows the source row nearest the thinnest supported sample.
- **Verification limit:** browser interaction/layout and live Streamlit deployment were not tested because the supported browser QA capability was unavailable. Software tests and Canvas rendering are not a substitute for browser acceptance testing. Earlier browser results below are historical.
- Distribution retains 99 files, standard unencrypted ZIP DEFLATE, CRC testing and clean-extraction manifest verification. No patient reports, extracted grids or private QA renders are packaged.

---

# Version 9.0.3 software verification — 16 October 2026

This release adds descriptive cone footprint tracking and a schematic eye around the corneal data. It does not validate a clinical cone boundary or exact eye reconstruction.

- All nine JavaScript suites passed. The regional/image/3D/cone suite contains 56 test groups, including unchanged scans, expansion with a fixed threshold, centroid translation in mm, incomplete coverage, flat maps, thinning direction, source-resolution labels, disconnected latest regions, OD/OS orientation, geometry invariance, missing thickness and reference-anatomy isolation.
- All 41 Python tests passed. Frozen model artifacts, scalar extraction, the image reader and existing assessment implementation remain unchanged. Interface/cache identifiers are updated.
- The tracker processed all 12 available map comparisons from the existing four private eye pairs. Eleven footprints were resolution-limited at the printed color-bin bounds; these are explicitly marked point estimates, not resolved borders. Partial-mask boundaries are flagged. This successful processing is not evidence that the estimated footprint is clinically accurate.
- Eight existing report reconstructions rendered in the reference-eye context with all five supported overlays. Geometry remained unchanged when switching overlays, and selected sample indices remained bound to source vertices. Front, side and cutaway paths completed. Reference anatomy has no patient measurement IDs.
- Production Canvas-renderer output was inspected locally. The delivered preview is generated entirely from explicitly fictional geometry and maps; no patient content is included.
- **Verification limit:** browser interaction/layout and live Streamlit deployment were not tested for this release because the supported browser QA capability was unavailable. Previous browser results below are historical.
- Distribution uses the same 99-file structure, standard unencrypted ZIP DEFLATE, CRC testing and clean-extraction manifest verification. Private reports, extracted grids and QA renders are excluded.

The tracker uses provisional display definitions and paired support, not repeatability-calibrated clinical thresholds. The reference-eye dimensions and placement are illustrative. Reference shape is labeled when elevation is unavailable; it never becomes measured patient geometry.

---

# Version 9.0.2 software verification — 16 October 2026

This release changes the corneal presentation and supported overlays. It does not establish a 1:1 anatomical replica or clinical accuracy.

- Nine JavaScript suites passed; the regional/image/3D suite now contains 47 groups. Added geometry tests cover physical-coordinate overlay sampling, missing overlays, different diameters, normal direction, preserved normal thickness, supported-triangle rim clipping, equal spatial units, cutaway support and wider native height apertures.
- All 41 Python tests passed. Model files, scalar extractor, map reader, case schema, assessments and observed-evidence implementation are unchanged from 9.0.1. The service change is the displayed interface version.
- The final renderer processed the eight previously extracted eye/visit reconstructions. Each supported the shaded surface plus thickness, anterior curvature, posterior curvature and anterior elevation. Overlay switching left the underlying front/back geometry unchanged. Surface pick indices remained associated with supported original samples. Front, side and cutaway renders completed.
- Exact production Canvas-renderer output was inspected using a local software canvas. A separate preview uses explicitly fictional geometry and contains no patient data. No new OCR/import test was needed because the reader and source-data contract are unchanged.
- **Verification limit:** browser interaction, layout and live Streamlit deployment were not tested in this release. The supported browser QA capability was unavailable. Earlier 9.0.1 browser results below are historical, not a claim that the revised UI passed those checks.
- Package validation: 99 files, standard unencrypted ZIP DEFLATE, CRC and clean-extraction manifest checks. No patient source reports, extracted grids or private rendered patient figures are distributed.

The image-based route still assumes the floating BFS position/tilt and infers the inner surface from thickness. The smooth display does not make those assumptions measured facts. Large missing areas remain absent; the display rim trims slightly inside the supported aperture and labels its diameter. Native surfaces use supplied coordinates up to a 12-mm aperture, subject to their own sampling limits.

---

# Version 9.0.1 software verification — 16 October 2026

Engineering results on the recovered exports; not clinical validation or a native-grid accuracy study.

- **Diameter failure:** reproduced with the fallback/primary OCR path. Small 9-mm tags were returned as 3 mm or only mm. Expanded crops and cross-checks against observed numeral shapes and units resolve the tested failures. The primary-only path was explicitly tested on both left-eye visits; no default diameter or BFS fitting diameter was substituted.
- **Real maps and 3D:** 16 original pages from four eyes at two visits (two patients) supplied 24 regional map layers and eight elevation/thickness reconstructions. The final sampler was applied to those original source pixels with their individually read legends. All eight 3D models rendered, with approximately 94–96% modeled central coverage after local smoothing. This is not a direct-read or accuracy percentage.
- **Paired coverage comparison:** for the available bilateral earlier/latest pair, version 9.0 sampled 54/62/65% (OD anterior/posterior/thickness) and 58/62/68% (OS). Version 9.0.1 sampled 72/79/88% and 76/78/89%, respectively. New coverage comes from balanced nearby visible colors, with direct and locally recovered coverage recorded separately. Final filtering also excludes isolated colored-marker contamination.
- **Complete import path:** the production browser extractor processed both original bilateral ZIPs in longitudinal mode. Four selected eye/visit sets each retained six numeric measurements, all three regional map layers and a shape estimate with a confirmed 9-mm plot. No extraction or JavaScript error was reported (220 OCR jobs). Dependency requests were served from local matching test libraries; hospital-network CDN availability was not tested. The final colored-marker guard was subsequently checked on the original pixels and the browser component.
- **Regression:** nine JavaScript suites passed; the regional/image/3D suite has 41 check groups. New cases cover narrow ink recovery, large gaps, one-sided support, inconsistent colors, direct/recovered accounting, diameter units, and rejection of isolated colored alignment ink. All 41 Python tests passed.
- **Browser UI:** the three-map layout, new coverage breakdown, OD/OS, earlier/latest, 3D profile, cutaway, mobile width, one-visit reconstruction, clearing and stale-input blocking passed without JavaScript errors. Desktop output was visually inspected.
- **Preserved model:** model artifacts, scalar extraction engine, assessment and observed evidence are unchanged from 9.0. Interface version/cache keys were updated.
- **Package:** 99 files, standard unencrypted DEFLATE ZIP, CRC and clean-extraction manifest verification passed. No source patient reports, extracted patient grids or private QA images are distributed.

The 3D view remains an approximate corneal segment with an assumed centered/untilted reference sphere and a thickness-derived inner surface. Its geometry is not an exact replica or a measured posterior surface. Increased coverage does not remove image quantization, alignment or scan-repeatability limits. The complete ZIP's supported Belin page supplies the 3D route; simply displaying a Four Maps Refractive page is not a numerical surface import.

---

# Version 9.0 software verification — 15 October 2026

These are engineering checks on the available report exports. They do not establish clinical accuracy, an exact anatomical reconstruction, or progression prediction.

- **Actual report calibration:** browser Tesseract.js 7 fast and best English readers processed 16 original report pages from four eyes at two visits (two patients). All eight Topometric/KC-Staging pages supplied anterior and posterior curvature maps; all eight Belin–Ambrósio pages supplied thickness maps. All 24 map layers passed the reader's calibration/schema checks. These fixtures do not represent every Pentacam layout.
- **Patient 3D:** the same eight Belin pages yielded a signed anterior elevation grid and a corroborated printed BFS radius. The elevation/thickness reconstruction produced a triangulated surface at all eight eye/visit combinations, with approximately 78–92% modeled central coverage after local smoothing. This includes supported interpolation across small text gaps. No native height ground truth was available; successful rendering is not an accuracy estimate.
- **Mathematical checks:** 36 regional/image/3D test groups passed, including spherical sag, normal-offset thickness, missing-data preservation, immutable inputs, mismatched geometry, insufficient coverage, measured-grid orientation, laterality, and rejection of synthetic geometry on the patient route. The 21 map-identification/source-boundary checks passed.
- **Regression:** all nine JavaScript suites and 41 Python tests passed. An obsolete progression-summary test stub that referenced a previously removed component was updated to the existing regional component.
- **Browser component:** Chromium rendered the three real extracted map layers and the fixed baseline-region result. Profile rotation, cutaway, earlier/latest selection, OD/OS selection, a 390-pixel mobile viewport, source clearing, stale-input blocking and one-visit reconstruction passed with no JavaScript errors. Desktop and mobile output were inspected. This test used actual extracted grids in the component; it was not a complete new-version ZIP-import or live-deployment test.
- **Preserved calculator:** frozen model files, scalar extractor core, case schema, assessment and observed-evidence modules remain byte-identical to version 8.9. The service and Streamlit changes are interface version/key changes. Spatial OCR now serializes access to the existing secondary reader and passes the new shape data through the report boundary.
- **Distribution:** 99 files in a standard unencrypted DEFLATE ZIP, without a ZIP64 requirement. CRC testing, clean extraction and per-file SHA-256 verification passed. Patient reports, extracted patient map grids, debug crops and private QA screenshots are excluded.

The image route assumes a centered, untilted floating reference sphere because its position/tilt are unavailable in these reports. The inner surface is inferred from pachymetry along the anterior normal; it is not the independently measured posterior surface. Original scans and legends remain the source. Native measured anterior/posterior height grids use a separate route.

---

# Version 8.9 software verification — 12 October 2026

These are engineering checks on available fixtures, not validation of clinical progression, registration or measurement accuracy.

- **Regional/image calculations:** 32 check groups passed. Added tests cover equivalent mm/D visits, posterior signed-power magnitudes, nonlinear interval conversion, cross-layer diameter mismatch, physical hotspot position, identical/uniform/opposite changes, missing peak samples, immutable inputs, plus-sign recognition and displaced swatch/label calibration.
- **Map identification and source boundary:** 21 checks passed, including real import-wrapper worker forwarding, source association and rejection of malformed image maps. The obsolete report-gallery test now targets the current regional component.
- **Actual images:** the browser pixel pipeline plus the packaged Tesseract.js 7 English model read all three target maps for four selected earlier/latest eye pairs (two OD, two OS), including mm/D changes across visits and different report margins. These 24 maps were engineering fixtures. Tightened pixel masking was then applied using their read legends; no native-grid ground truth was available.
- **Complete ZIP import:** production ZIP discovery, six-field scalar extraction, report attachment and regional image reading processed two full bilateral report ZIPs using local WebAssembly OCR and Node Canvas. Both archives produced OD and OS, six scalar values per eye and all three target map types, without map-reading issues. Both visit pairs retained all three maps. Paired readable coverage was approximately 54/62/65% (OD) and 58/62/68% (OS), for anterior/posterior/thickness. This test used 565 local OCR reads; it is not a clinic throughput benchmark or a test of the CDN on a hospital network.
- **Browser UI:** Chromium displayed three maps from the actual extracted grids. OD/OS source switching and nasal/temporal label orientation, shared-view selection, location inspection, PNG export, stale-source blocking after edits, dirty-state clearing and next-patient clearing passed. Four viewport widths (1240, 760, 390, 320 px) had no page overflow. Desktop and mobile output were inspected. Zero JavaScript errors in this test.
- **Live app:** Streamlit 1.50 launched and calculated the synthetic bilateral example through the Python service. The updated regional dropdown and component assets loaded successfully.
- **Preserved model:** 16 baseline/longitudinal cases across eyes, ages, scan intervals and quality flags matched 8.8 exactly apart from the interface version. Frozen model files, scalar extractor, case schema, assessment and observed-evidence code remain byte-identical.
- **Bilateral regression:** existing discovery tests passed for current/legacy/mixed formats, eye association, partial inputs, folder boundaries, missing titles, cancellation and retained edits.
- **Distribution:** 99 short relative file paths in a standard unencrypted DEFLATE ZIP, with no ZIP64 requirement. CRC testing, extraction and per-file SHA-256 verification passed. Patient reports, patient data rows, extracted patient map grids, QA screenshots and debug crops are excluded.

The automated reader is limited to the supported original report layouts. Coarse legends, text, scan variability and display alignment limit the maps. A relative hotspot does not establish progression, and blank/missing regions do not establish stability. The 0.8-mm window, masking and display scales are engineering settings, not validated biological thresholds.

---

# Version 8.8 software verification

These checks establish implementation behavior on the available fixtures, not clinical accuracy or diagnostic validity.

- **Actual report workflow:** the real ZIP discovery and `attachAssociatedReportPages` import wrapper processed the available January and March report archives in Chromium, using the existing Tesseract worker through a local test bridge. Each archive produced two associated studies and all three target image maps per study (front curvature, back curvature, thickness). All twelve grids passed interval/schema checks. Both paired studies had three comparable maps; common readable coverage was approximately 54% and 49%. Identical-image comparisons produced zero highlighted shifts.
- **Additional formats:** the local reader successfully read an available 1200 × 838 export with a front diopter scale, back radius scale and thickness scale; a 1200 × 910 legacy thickness report with a different printed thickness legend also parsed. These are engineering fixtures, not a representative clinic accuracy benchmark. Arbitrary layouts are not covered.
- **Regional tests:** 22 numerical/image test groups passed, including original area calculations, monotonic scale requirements, missing/obscured color handling, identical scans, overlapping color intervals, radius/thickness direction, signed posterior D, matching units/diameters, insufficient coverage, invalid intervals, and different numeric calibrations for the same color.
- **Preserved calculator:** 16 baseline/longitudinal cases across eyes, ages, intervals and quality flags produced exactly the same numeric outputs as 8.7 apart from the interface version. Frozen model files, scalar extractor engine and observed-evidence code are byte-identical. The new report attachment wrapper adds only the separate image estimates.
- **Browser integration:** actual extracted image grids traversed the nested importer message boundary and displayed through Current case after calculation. Layer switching, location inspection, original-source binding, invalidation after edits, and next-patient clearing passed. Simulated numerical maps remained excluded from the automatic patient route. Zero JavaScript errors.
- **Layout:** 1200, 760, 390 and 320-pixel widths passed page overflow checks. The inspection table scrolls horizontally on narrow screens, preserving readable labels.
- **Bilateral discovery:** existing tests passed for current/legacy/mixed reports, partial inputs, eye association, folder boundaries, cancellation and retained edits.
- **Actual Streamlit 1.50:** launch, Python calculation, regional dropdown and 8.8 footer passed without an app exception.
- **Distribution:** standard unencrypted DEFLATE ZIP, no ZIP64 requirement, 99 short relative file paths. CRC testing, clean extraction and per-file SHA-256 verification passed. No patient report images, patient rows, debug crops or QA results are distributed.

The image reader uses printed plot geometry, not anatomical registration. Its percentages and color-derived values have not been validated against device grids or adjudicated progression. This is an experimental visual supplement; it does not change NKPI or resolve scan-quality uncertainty.

---

# Version 8.7 software verification

These checks verify software behavior. They do not establish clinical accuracy, repeatability or progression detection.

- Thirteen numerical test groups passed: physical/nonuniform cell areas, directional posterior curvature, thinning, unchanged scans, null masking, one-layer and no-common-data behavior, mismatched eyes/visits/units/grids/registration definitions, sign conventions, invalid inputs, synthetic/real separation, nearby/apart patterns, immutable inputs and explicit audit labeling.
- Sixteen deterministic synthetic baseline/longitudinal cases spanning both eyes, quality flags and scan intervals produced exactly the same numerical outputs as 8.6, apart from the interface version. Model artifacts, extractor files, schema and observed-evidence calculations are byte-identical.
- The existing bilateral discovery test passed (legacy/current/mixed formats, missing/partial inputs, separate-eye associations, cancellation and edits).
- Chromium exercised the real calculator component with the Python calculation service: scores, observed evidence, report messaging, synthetic-map exclusion from the patient path, numerical binding, invalidation after edits, and next-patient clearing. Zero JavaScript errors.
- The separate numerical-pair route was tested with the synthetic JSON, malformed replacement, map switching, map-cell inspection and adjustable cutoffs. Invalid replacement clears the prior result.
- Offline demo widths 1200, 760, 390 and 320 pixels passed horizontal overflow checks. Desktop/mobile screenshots were visually reviewed.
- Actual Streamlit 1.50 launch passed. The bilateral example calculated through the live server, the new regional dropdown rendered, and the footer showed 8.7.0-regional-change. No app exception appeared. Top spacing was corrected so Streamlit’s toolbar does not cover action buttons.
- The 99-file ZIP uses standard DEFLATE compression with short relative paths, no encryption, and no ZIP64 requirement. CRC testing, extraction and per-file hash comparison passed. No patient records or source report images are included.

Tests used synthetic numerical maps and mock report pixels. Anatomical registration and clinical performance were not tested on measured patient grids. Report-only JPEG exports cannot validate this engine. The old full-workflow OCR was preserved, not newly benchmarked on an entire clinic cohort.
